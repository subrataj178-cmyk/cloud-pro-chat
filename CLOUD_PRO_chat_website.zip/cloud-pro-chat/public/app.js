const socket = io();
const $ = id => document.getElementById(id);
const state = { name: "", rooms: [], room: null, privatePassword: "", messages: [] };
const emojis = { General: "☁", Gaming: "🎮", Music: "♫", Technology: "⌘" };
let selectedAccess = "public", toastTimer;

function toast(message) {
  $("toast").textContent = message;
  $("toast").classList.remove("hidden");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => $("toast").classList.add("hidden"), 2800);
}
function showError(message) {
  $("errorBar").textContent = message;
  $("errorBar").classList.remove("hidden");
  setTimeout(() => $("errorBar").classList.add("hidden"), 5000);
}
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
}
function initials(name) { return (name || "?").trim().slice(0, 1).toUpperCase(); }
function timeText(timestamp) { return new Date(timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }); }

$("year").textContent = new Date().getFullYear();
$("saveName").addEventListener("click", startWithName);
$("username").addEventListener("keydown", e => { if (e.key === "Enter") startWithName(); });
function startWithName() {
  const name = $("username").value.trim().slice(0,20);
  if (name.length < 2) return toast("Choose a nickname with at least 2 characters.");
  state.name = name;
  socket.emit("profile:set", name);
  toast("Nickname saved. Pick a room to start chatting.");
}
socket.on("profile:ready", ({ name }) => {
  state.name = name;
  $("username").value = name;
  $("welcome").classList.remove("hidden");
});

function requireName() {
  if (state.name.length >= 2) return true;
  const name = $("username").value.trim().slice(0,20);
  if (name.length < 2) { toast("Choose your display name first."); $("username").focus(); return false; }
  state.name = name; socket.emit("profile:set", name); return true;
}
function roomEmoji(room) { return emojis[room.name] || (room.access === "private" ? "🔒" : "✦"); }
function renderRooms() {
  const publicRooms = state.rooms.filter(r => r.access === "public");
  $("roomCount").textContent = publicRooms.length;
  $("liveRooms").textContent = publicRooms.length;
  $("roomList").innerHTML = publicRooms.map(r => `<button class="room-link" data-room="${r.id}"><span class="hash">#</span><span>${escapeHTML(r.name)}</span><small>${r.count}</small></button>`).join("");
  $("roomCards").innerHTML = publicRooms.length ? publicRooms.map(r => `<button class="room-card" data-room="${r.id}"><span class="room-emoji">${roomEmoji(r)}</span><strong>${escapeHTML(r.name)}</strong><p>${escapeHTML(r.topic)}</p><small>♙ ${r.count} online · JOIN ROOM →</small></button>`).join("") : '<p class="fine">No public rooms are available right now.</p>';
  document.querySelectorAll("[data-room]").forEach(btn => btn.addEventListener("click", () => joinRoom(btn.dataset.room)));
}
socket.on("rooms:list", rooms => { state.rooms = rooms; renderRooms(); });
socket.on("app:error", message => { showError(message); toast(message); });
socket.on("room:created", data => {
  state.privatePassword = data.password || "";
  toast(data.access === "private" ? `Private room created. ID: ${data.id}` : `Room created. ID: ${data.id}`);
});
function joinRoom(id) {
  if (!requireName()) return;
  const room = state.rooms.find(r => r.id === id);
  if (room?.access === "private") {
    const password = prompt("Enter this private room's password:");
    if (password === null) return;
    socket.emit("rooms:join", { id, password });
  } else socket.emit("rooms:join", { id });
}
socket.on("room:joined", data => {
  state.room = data.room;
  state.messages = data.messages || [];
  $("welcome").classList.add("hidden");
  $("chatView").classList.remove("hidden");
  $("chatRoomName").textContent = data.room.name;
  $("chatRoomTopic").textContent = data.room.topic;
  $("roomIdText").textContent = data.room.id;
  $("roomPrivacy").textContent = data.room.access.toUpperCase();
  $("messages").innerHTML = "";
  state.messages.forEach(renderMessage);
  renderMembers(data.members || []);
  $("messageInput").focus();
});
function renderMessage(message) {
  const box = $("messages");
  const empty = box.querySelector(".message-empty");
  if (empty) empty.remove();
  if (message.system) {
    const el = document.createElement("div"); el.className = "system-msg"; el.textContent = message.text; box.appendChild(el);
  } else {
    const article = document.createElement("article"); article.className = "message";
    const avatar = document.createElement("div"); avatar.className = "msg-avatar"; avatar.textContent = initials(message.name);
    const content = document.createElement("div"); content.className = "msg-content";
    const meta = document.createElement("div"); meta.className = "msg-meta";
    const name = document.createElement("b"); name.textContent = message.name;
    const time = document.createElement("time"); time.textContent = timeText(message.time);
    const text = document.createElement("div"); text.className = "msg-text"; text.textContent = message.text;
    meta.append(name, time); content.append(meta, text); article.append(avatar, content); box.appendChild(article);
  }
  box.scrollTop = box.scrollHeight;
}
socket.on("message:new", message => renderMessage(message));
socket.on("system:message", message => renderMessage({ ...message, system: true }));
socket.on("room:members", members => renderMembers(members));
function renderMembers(members) {
  $("memberCount").textContent = members.length;
  $("memberList").innerHTML = members.map(m => `<div class="member"><span class="msg-avatar">${escapeHTML(initials(m.name))}</span><span>${escapeHTML(m.name)}${m.name === state.name ? " (you)" : ""}</span></div>`).join("");
}
$("messageForm").addEventListener("submit", e => {
  e.preventDefault();
  const input = $("messageInput"), text = input.value.trim();
  if (!text || !state.room) return;
  socket.emit("message:send", text);
  input.value = ""; $("charCount").textContent = "0 / 500"; input.style.height = "auto";
});
$("messageInput").addEventListener("input", e => {
  $("charCount").textContent = `${e.target.value.length} / 500`;
  e.target.style.height = "auto"; e.target.style.height = Math.min(e.target.scrollHeight, 110) + "px";
});
$("messageInput").addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); $("messageForm").requestSubmit(); } });
function leaveRoom() { if (state.room) socket.emit("room:leave"); state.room = null; $("chatView").classList.add("hidden"); $("welcome").classList.remove("hidden"); }
$("leaveBtn").addEventListener("click", leaveRoom); $("backBtn").addEventListener("click", leaveRoom);
$("homeBtn").addEventListener("click", leaveRoom);
$("refreshRooms").addEventListener("click", () => { renderRooms(); toast("Room list refreshed."); });
$("copyRoom").addEventListener("click", async () => {
  if (!state.room) return;
  try { await navigator.clipboard.writeText(state.room.id); toast("Room ID copied."); }
  catch { prompt("Copy this room ID:", state.room.id); }
});
$("shareInvite").addEventListener("click", async () => {
  if (!state.room) return;
  const details = `CLOUD PRO room: ${state.room.name}\nRoom ID: ${state.room.id}` + (state.privatePassword ? `\nPassword: ${state.privatePassword}` : "");
  try { if (navigator.share) await navigator.share({ title: "CLOUD PRO room invite", text: details }); else { await navigator.clipboard.writeText(details); toast("Room details copied."); } }
  catch { prompt("Copy these room details and share privately:", details); }
});
$("reportBtn").addEventListener("click", () => {
  const reason = prompt("Describe the problem (don't include private information):");
  if (reason && reason.trim()) socket.emit("message:report", { text: reason.trim() });
});
socket.on("report:received", message => toast(message));

function openCreate() {
  if (!requireName()) return;
  $("modalBackdrop").classList.remove("hidden");
  $("roomName").focus();
}
$("createBtn").addEventListener("click", openCreate); $("createNav").addEventListener("click", openCreate);
$("modalClose").addEventListener("click", () => $("modalBackdrop").classList.add("hidden"));
$("modalBackdrop").addEventListener("click", e => { if (e.target === $("modalBackdrop")) $("modalBackdrop").classList.add("hidden"); });
document.querySelectorAll("[data-access]").forEach(btn => btn.addEventListener("click", () => {
  selectedAccess = btn.dataset.access;
  document.querySelectorAll("[data-access]").forEach(b => b.classList.toggle("selected", b === btn));
  $("passwordField").classList.toggle("hidden", selectedAccess !== "private");
  $("roomPassword").required = selectedAccess === "private";
}));
$("createForm").addEventListener("submit", e => {
  e.preventDefault();
  if (!requireName()) return;
  const name = $("roomName").value.trim();
  const password = $("roomPassword").value;
  if (selectedAccess === "private" && password.length < 4) return toast("Private room passwords must be at least 4 characters.");
  socket.emit("rooms:create", { name, topic: $("roomTopic").value.trim(), access: selectedAccess, password });
  $("modalBackdrop").classList.add("hidden");
  $("createForm").reset(); selectedAccess = "public";
  document.querySelectorAll("[data-access]").forEach(b => b.classList.toggle("selected", b.dataset.access === "public"));
  $("passwordField").classList.add("hidden");
});
socket.on("connect", () => { if (state.name) socket.emit("profile:set", state.name); });
socket.on("disconnect", () => toast("Connection lost. Reconnecting…"));
socket.on("connect_error", () => toast("Can't connect to chat server. Try refreshing the page."));
