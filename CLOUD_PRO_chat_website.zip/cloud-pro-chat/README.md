# CLOUD PRO — real-time chat starter

Custom-branded chat app for **CLOUD PRO**, owner display **@DARK_ZORO**. It uses Node.js, Express and Socket.IO.

## Included
- Live public topic rooms
- Create public or password-protected private rooms
- Room IDs and room invite sharing
- Nicknames without account registration
- Live participant list and real-time text messages
- In-memory recent messages (last 60 per room)
- Basic message rate limit and report event
- Responsive dark-purple / neon-cyan UI

## Run locally
1. Install Node.js 18 or newer on a computer.
2. Extract this ZIP.
3. Open a terminal in the extracted folder.
4. Run `npm install`
5. Run `npm start`
6. Open `http://localhost:3000`

For a phone-only workflow, upload this project to a Git repository and use a Node.js hosting provider's deploy-from-repository flow. The host must support a long-running Node.js web service and WebSockets. Static-only hosting will not run the chat backend.

## Before public launch
This is a starter project, not a production-audited service. It does not include account authentication, a full moderation/admin panel, persistent storage, abuse escalation, or end-to-end encryption. The report event is logged by the server; it does not automatically contact a moderator. Add stronger moderation, rate limiting, monitoring, privacy notice, terms, and a secure admin workflow before inviting the public.

Messages and room state are held in server memory and disappear when the server restarts. Room passwords are stored as SHA-256 digests in memory; this is not a substitute for a production password-management design. Private room IDs are random, but users must share them and passwords carefully. Chat messages are not end-to-end encrypted. Anyone in a room can copy messages or take screenshots.

## Environment
- `PORT` (optional; hosting providers commonly set this automatically)

## Safety
Don't claim messages are impossible to recover or that users are fully anonymous. Avoid sharing personal information. Moderate user-generated content before public use.
