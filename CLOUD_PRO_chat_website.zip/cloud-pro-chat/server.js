const express = require("express");
const http = require("http");
const path = require("path");
const crypto = require("crypto");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { maxHttpBufferSize: 1e5 });
const PORT = process.env.PORT || 3000;

app.disable("x-powered-by");
app.use(express.static(path.join(__dirname, "public")));
app.get("/health", (_req, res) => res.json({ ok: true, app: "CLOUD PRO" }));

// Rooms and messages live in server memory only. Restarting the server clears them.
const rooms = new Map();
const userState = new Map();
const DEFAULT_ROOMS = [
  { name: "General", topic: "Everyday conversations", access: "public" },
  { name: "Gaming", topic: "Games and players", access: "public" },
  { name: "Music", topic: "Songs and artists", access: "public" },
  { name: "Technology", topic: "Tech and gadgets", access: "public" }
];

function cleanText(value, max = 180) {
  return String(value ?? "").replace(/[<>]/g, "").replace(/\s+/g, " ").trim().slice(0, max);
}
function makeId() {
  return crypto.randomBytes(4).toString("hex").toUpperCase();
}
function passwordDigest(password) {
  return crypto.createHash("sha256").update(String(password)).digest("hex");
}
function safeRoom(room) {
  return {
    id: room.id, name: room.name, topic: room.topic, access: room.access,
    count: room.members.size
  };
}
function publicRooms() {
  return [...rooms.values()].filter(r => r.access === "public").map(safeRoom);
}
function sendRoomList() {
  io.emit("rooms:list", publicRooms());
}
function createRoom({ name, topic = "", access = "public", password = "" }, ownerSocket = null) {
  const id = makeId();
  const room = {
    id, name: cleanText(name, 36), topic: cleanText(topic, 90) || "A CLOUD PRO room",
    access, passwordHash: access === "private" ? passwordDigest(password) : null,
    members: new Map(), messages: [], createdAt: Date.now()
  };
  rooms.set(id, room);
  if (ownerSocket) room.owner = ownerSocket;
  return room;
}
DEFAULT_ROOMS.forEach(r => createRoom(r));

function emitMembers(room) {
  io.to(room.id).emit("room:members", [...room.members.values()].map(m => ({ name: m.name })));
}
function leaveCurrent(socket) {
  const state = userState.get(socket.id);
  if (!state || !state.roomId) return;
  const room = rooms.get(state.roomId);
  if (room) {
    room.members.delete(socket.id);
    socket.leave(room.id);
    io.to(room.id).emit("system:message", { text: `${state.name} left the room`, time: Date.now() });
    emitMembers(room);
    if (room.members.size === 0 && room.access === "private") rooms.delete(room.id);
  }
  state.roomId = null;
  sendRoomList();
}
function tooFast(state) {
  const now = Date.now();
  state.sent = (state.sent || []).filter(t => now - t < 8000);
  if (state.sent.length >= 6) return true;
  state.sent.push(now);
  return false;
}

io.on("connection", socket => {
  userState.set(socket.id, { name: "Guest", roomId: null, sent: [] });
  socket.emit("rooms:list", publicRooms());

  socket.on("profile:set", rawName => {
    const state = userState.get(socket.id);
    if (!state) return;
    state.name = cleanText(rawName, 20) || "Guest";
    socket.emit("profile:ready", { name: state.name });
  });

  socket.on("rooms:create", payload => {
    const state = userState.get(socket.id);
    if (!state) return;
    const name = cleanText(payload?.name, 36);
    const topic = cleanText(payload?.topic, 90);
    const access = payload?.access === "private" ? "private" : "public";
    const password = String(payload?.password || "").slice(0, 64);
    if (name.length < 2) return socket.emit("app:error", "Room name must be at least 2 characters.");
    if (access === "private" && password.length < 4) return socket.emit("app:error", "Private room passwords must be at least 4 characters.");
    if (rooms.size >= 80) return socket.emit("app:error", "Room limit reached. Please try again later.");
    const room = createRoom({ name, topic, access, password }, socket.id);
    socket.emit("room:created", { id: room.id, name: room.name, access: room.access, password: access === "private" ? password : null });
    sendRoomList();
    joinRoom(socket, room.id, password);
  });

  socket.on("rooms:join", payload => {
    const id = cleanText(payload?.id, 12).toUpperCase();
    const password = String(payload?.password || "").slice(0, 64);
    const room = rooms.get(id);
    if (!room) return socket.emit("app:error", "Room not found. Check the room ID.");
    if (room.access === "private" && room.passwordHash !== passwordDigest(password)) {
      return socket.emit("app:error", "That private-room password is incorrect.");
    }
    joinRoom(socket, id, password);
  });

  function joinRoom(socket, id) {
    const state = userState.get(socket.id);
    const room = rooms.get(id);
    if (!state || !room) return;
    leaveCurrent(socket);
    state.roomId = id;
    room.members.set(socket.id, { name: state.name, joinedAt: Date.now() });
    socket.join(id);
    socket.emit("room:joined", {
      room: safeRoom(room),
      messages: room.messages.slice(-40),
      members: [...room.members.values()].map(m => ({ name: m.name }))
    });
    io.to(id).emit("system:message", { text: `${state.name} joined the room`, time: Date.now() });
    emitMembers(room);
    sendRoomList();
  }

  socket.on("message:send", raw => {
    const state = userState.get(socket.id);
    if (!state || !state.roomId) return socket.emit("app:error", "Join a room before sending messages.");
    const room = rooms.get(state.roomId);
    if (!room) return;
    const text = cleanText(raw, 500);
    if (!text) return;
    if (tooFast(state)) return socket.emit("app:error", "You're sending messages too quickly. Please wait a moment.");
    const message = { id: crypto.randomBytes(6).toString("hex"), name: state.name, text, time: Date.now() };
    room.messages.push(message);
    if (room.messages.length > 60) room.messages.shift();
    io.to(room.id).emit("message:new", message);
  });

  socket.on("message:report", payload => {
    const state = userState.get(socket.id);
    const text = cleanText(payload?.text, 300);
    if (state && text) {
      // Minimal starter report logging; configure a private moderation workflow before public launch.
      console.warn("[CLOUD PRO REPORT]", { roomId: state.roomId, reporter: state.name, text, at: new Date().toISOString() });
      socket.emit("report:received", "Report noted. A site moderator must review server reports.");
    }
  });

  socket.on("room:leave", () => leaveCurrent(socket));
  socket.on("disconnect", () => {
    leaveCurrent(socket);
    userState.delete(socket.id);
  });
});

const listener = server.listen(PORT, () => console.log(`CLOUD PRO running on port ${PORT}`));
listener.requestTimeout = 15000;
